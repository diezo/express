class Authentication:

    beta: bool = True

    def __init__(self) -> None:
        pass
